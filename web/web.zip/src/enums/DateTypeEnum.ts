/**
 * 日期类型
 */
export enum DateTypeEnum {
  Date = 'date',
  Datetime = 'datetime',
  Time = 'time',
}
