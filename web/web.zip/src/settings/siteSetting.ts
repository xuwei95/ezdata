// github repo url
export const GITHUB_URL = 'https://github.com/jeecgboot/JeecgBoot';

// vue-Jeecg-admin-next-doc
export const DOC_URL = 'https://help.jeecg.com';

// site url
export const SITE_URL = 'http://www.jeecg.com';
